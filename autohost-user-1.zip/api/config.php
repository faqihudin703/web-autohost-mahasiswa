<?php
/**
 * File Konfigurasi Pusat untuk Frontend.
 * Simpan semua variabel yang mungkin berubah di sini.
 * PENTING: Jangan simpan data sensitif seperti password di sini.
 */

// Definisikan URL dasar (base) dari API backend Anda.
// Ini adalah satu-satunya tempat Anda perlu mengubah URL jika pindah server.
define('API_BASE_URL', 'API-BACK-END');

?>